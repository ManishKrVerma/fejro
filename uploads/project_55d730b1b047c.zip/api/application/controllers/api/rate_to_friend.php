<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Example
 *
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array.
 *
 * @package		CodeIgniter
 * @subpackage	Rest Server
 * @category	Controller
 * @author		Phil Sturgeon
*/

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH.'/libraries/REST_Controller.php';

class Rate_to_friend extends REST_Controller
{
	function __construct()
    {
        // Construct our parent class
        parent::__construct();
        
        // Configure limits on our controller methods. Ensure
        // you have created the 'limits' table and enabled 'limits'
        // within application/config/rest.php
        $this->methods['user_get']['limit'] = 500; //500 requests per hour per user/key
        $this->methods['user_post']['limit'] = 100; //100 requests per hour per user/key
        $this->methods['user_delete']['limit'] = 50; //50 requests per hour per user/key
    }
	
    /* ==================================================================== */
	/**
     *  This function is used to rate friend.
     */
	 
    function ratetofriend_post(){
		/* loading required modal */
        $this->load->model('profile_screen_model','obj_ps',TRUE);
		
		/* Call model function to get array from database, according to provided user id */
		$returnVal = $this->obj_ps->ratetofriend_post($this->get('id'), $this->post('rated_user_id'), $this->post('rate'),  $this->post('rate_type'),  $this->post('rating_status') );
		
		if($returnVal){
			/* successfully get data from db */
			$this->response($returnVal, 200);
		}else{
			/* failed */
			$this->response(array('error' => 'ERROR! try again'), 404);
		}
    }
    
}