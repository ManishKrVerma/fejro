<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Example
 *
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array.
 *
 * @package		CodeIgniter
 * @subpackage	Rest Server
 * @category	Controller
 * @author		Phil Sturgeon
*/

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH.'/libraries/REST_Controller.php';

class Setting_page extends REST_Controller
{
	function __construct()
    {
        // Construct our parent class
        parent::__construct();
        
        // Configure limits on our controller methods. Ensure
        // you have created the 'limits' table and enabled 'limits'
        // within application/config/rest.php
        $this->methods['user_get']['limit'] = 500; //500 requests per hour per user/key
        $this->methods['user_post']['limit'] = 100; //100 requests per hour per user/key
        $this->methods['user_delete']['limit'] = 50; //50 requests per hour per user/key
    }
	
    /* ==================================================================== */
	/**
     *  This function is used to get user details by user id.
     */
	 
    function user_get(){	
        /* loading required modal */
        $this->load->model('profile_screen_model','obj_ps',TRUE);
		
		/* Call model function to get array from database, according to provided user id */
		$returnVal = $this->obj_ps->setting_detail_by_user_id($this->get('id'));
		
		if($returnVal){
			/* successfully get data from db */
			$this->response($returnVal, 200);
		}else{
			/* failed */
			$this->response(array('error' => 'User could not be found'), 404);
		}
    }
	 /* ==================================================================== */
	/**
     *  This function is used to get updaterrevelreq details by user id.
     */
	 
    function updaterrevelreq_get(){	
        /* loading required modal */
        $this->load->model('profile_screen_model','obj_ps',TRUE);
		
		/* Call model function to get array from database, according to provided user id */
		$returnVal = $this->obj_ps->updaterrevelreq_by_user_id($this->get('id'));
		
		if($returnVal){
			/* successfully get data from db */
			$this->response($returnVal, 200);
		}else{
			/* failed */
			$this->response(array('error' => 'User could not be found'), 404);
		}
    }

	
	/* ==================================================================== */
	/**
     *  This function is used to update notifications user id.
     */
	 
    function updatenote_post(){
		/* loading required modal */
        $this->load->model('profile_screen_model','obj_ps',TRUE);
		
		/* Call model function to get array from database, according to provided user id */
		$returnVal = $this->obj_ps->updatenote_post($this->get('id'), $this->post('notifications'));
		
		if($returnVal){
			/* successfully get data from db */
			$this->response($returnVal, 200);
		}else{
			/* failed */
			$this->response(array('error' => 'ERROR! try again'), 404);
		}
	}
	
    /* ==================================================================== */
	/**
     *  This function is used to update Publicize my testimonials by user id.
     */
	 
	public function updatepmt_post(){
		/* loading required modal */
        $this->load->model('profile_screen_model','obj_ps',TRUE);
		
		/* Call model function to get array from database, according to provided user id */
		$returnVal = $this->obj_ps->updatepmt_post($this->get('id'), $this->post('publicize_my_testimonials'));
		
		if($returnVal){
			/* successfully get data from db */
			$this->response($returnVal, 200);
		}else{
			/* failed */
			$this->response(array('error' => 'ERROR! try again'), 404);
		}
	}
		
    /* ==================================================================== */
	/**
     *  This function is used to update Publicize my rating by user id.
     */
	 
    function updatepmr_post(){
		/* loading required modal */
        $this->load->model('profile_screen_model','obj_ps',TRUE);
		
		/* Call model function to get array from database, according to provided user id */
		$returnVal = $this->obj_ps->updatepmr_post($this->post('id'), $this->post('publicize_my_rating'));
		
		if($returnVal){
			/* successfully get data from db */
			$this->response($returnVal, 200);
		}else{
			/* failed */
			$this->response(array('error' => 'ERROR! try again'), 404);
		}
	}
			
    /* ==================================================================== */
	/**
     *  This function is used to update rate anonymously by user id.
     */
	 
    function updaterateanony_post(){
		/* loading required modal */
        $this->load->model('profile_screen_model','obj_ps',TRUE);
		
		/* Call model function to get array from database, according to provided user id */
		$returnVal = $this->obj_ps->updaterateanony_post($this->get('id'), $this->post('rate_anonymously'));
		
		if($returnVal){
			/* successfully get data from db */
			$this->response($returnVal, 200);
		}else{
			/* failed */
			$this->response(array('error' => 'ERROR! try again'), 404);
		}
	}
	/* ==================================================================== */
	/**
     *  This function is used to update Reveal Requests Remaining by user id.
     */	 
    function updaterrevelreq_post(){
		/* loading required modal */
        $this->load->model('profile_screen_model','obj_ps',TRUE);
		
		/* Call model function to get array from database, according to provided user id */
		$returnVal = $this->obj_ps->updaterrevelreq_post($this->get('id'), $this->post('reveal_request_remaining'));
		
		if($returnVal){
			/* successfully get data from db */
			$this->response($returnVal, 200);
		}else{
			/* failed */
			$this->response(array('error' => 'ERROR! try again'), 404);
		}
	}
	
	
	
	
	
    
}