<?php

if (!defined('BASEPATH'))
    exit('No direct script allowed');

class Profile_screen_model extends CI_Model {

    //------------------------------------------------------------------------
    /*
     * Default constructor
     */
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
    }

	/* ==================================================================== */
	/**
     *  This function is used to get user details by user id for profile screen page
     */
	 
	public function profile_screen_detail_by_user_id($id){
		$this->db->from('restapi_user as user');
		$this->db->join('restapi_rating as rating', 'rating.FK_rater_user_id = user.user_id');
		$this->db->where(array('user_id' => $id));
		$result = $this->db->get();
		$arr_value = array();
        $data = array();
		if ($result && $result->num_rows() > 0) {            
            foreach ($result->result() as $row) {
                if (!array_key_exists($row->user_id, $data)) {
                    $data[$row->user_id] = array();
                }
                if (array_key_exists($row->user_id, $data)) {
                    $data[$row->user_id] = array(                        
                        'user_id' => $row->user_id,
                        'rater_user_name' => $row->user_name,
						'profile_status' =>  $row->user_status,
						'create_on' => $row->create_on,
						'last_login' => $row->last_login,
						'last_logout' => $row->last_logout,
						'account_status' => $row->account_status,
						'update_on' => $row->update_on,
						'rating_status' => $row->rating_status,
						'rate' => $row->rate,
					);
                    array_push($arr_value, $data[$row->user_id]);                    
                }
            } 
			return $arr_value;
        }else{
			return false;
		}		
	}
	
	/* ==================================================================== */
	/**
     *  This function is used to get user details by user id for setting page
     */
	 
	public function setting_detail_by_user_id($id){
		$this->db->from('restapi_user as user');
		$this->db->where(array('user_id' => $id));
		$result = $this->db->get();
		//print_r($result->result());
		$arr_value = array();
        $data = array();
		if ($result && $result->num_rows() > 0) {            
            foreach ($result->result() as $row) {
                if (!array_key_exists($row->user_id, $data)) {
                    $data[$row->user_id] = array();
                }
                if (array_key_exists($row->user_id, $data)) {
                    $data[$row->user_id] = array(                        
                        'user_id' => $row->user_id,
                        'user_name' => $row->user_name,
                        'notifications' => $row->notifications,
						'publicize_my_rating' => $row->publicize_my_rating,
						'publicize_my_testimonials' => $row->publicize_my_testimonials,
						'rate_anonymously' => $row->rate_anonymously,
						'reveal_request_remaining' => $row->reveal_request_remaining,
					);
                    array_push($arr_value, $data[$row->user_id]);                    
                }
            } 
			return $arr_value;
        }else{
			return false;
		}		
	}	
	
	/* ==================================================================== */
	/**
     *  This function is used to get For: Reveal Requests Accept/Rejected
     */
	 
	public function updaterrevelreq_by_user_id($id){
		$this->db->from('restapi_user as user');
		$this->db->where(array('user_id' => $id));
		$result = $this->db->get();
		//print_r($result->result());
		$arr_value = array();
        $data = array();
		if ($result && $result->num_rows() > 0) {
            foreach ($result->result() as $row) {
                if (!array_key_exists($row->user_id, $data)) {
                    $data[$row->user_id] = array();
                }
                if (array_key_exists($row->user_id, $data)) {
                    $data[$row->user_id] = array(                        
                        'user_id' => $row->user_id,
                        'user_name' => $row->user_name,
                        'notifications' => $row->notifications,
						'publicize_my_rating' => $row->publicize_my_rating,
						'publicize_my_testimonials' => $row->publicize_my_testimonials,
						'rate_anonymously' => $row->rate_anonymously,
						'reveal_request_remaining' => $row->reveal_request_remaining,
					);
                    array_push($arr_value, $data[$row->user_id]);                    
                }
            } 
			return $arr_value;
        }else{
			return false;
		}		
	}	
		
	/* ==================================================================== */
	/**
     *  This function is used to get rating, revel request status by user id for Notification  page
     */
	 
	public function notification_detail_by_user_id($id){
		$result = $this->db->get_where('restapi_notification',array('receiver_user_id' => $id));
		$arr_value = array();
        $data = array();
		if ($result && $result->num_rows() > 0) {
            foreach ($result->result() as $row) {
                if (!array_key_exists($row->notification_id, $data)) {
                    $data[$row->notification_id] = array();
                }
                if (array_key_exists($row->notification_id, $data)) {
                    $data[$row->notification_id] = array(                        
                        'notification_id' => $row->notification_id,
                        'notification_status' => $row->notification_status,
                        'sender_user_id' => $row->sender_user_id,
						'receiver_user_id' => $row->receiver_user_id,
						'notification_date' => $row->notification_date,
						'notification_time' => $row->notification_time,
					);
                    array_push($arr_value, $data[$row->notification_id]);                    
                }
            } 
			return $arr_value;
        }else{
			return false;
		}
		/* previous logic changed on 22.7.2015
		$this->db->from('restapi_rating as rating');
		$this->db->join('restapi_user as user', 'user.user_id = rating.FK_rater_user_id');
		$this->db->where(array('FK_rated_user_id' => $id, 'flag' => 'unread'));
		$result = $this->db->get();
		//print_r($result->result());
		$arr_value = array();
        $data = array();
		if ($result && $result->num_rows() > 0) {
            foreach ($result->result() as $row) {
                if (!array_key_exists($row->rating_id, $data)) {
                    $data[$row->rating_id] = array();
                }
                if (array_key_exists($row->rating_id, $data)) {
					/* get rater user namex`
					$this->db->select('user_name');
					$this->db->from('restapi_user as user');
					$this->db->join('restapi_rating as rating', 'rating.FK_rater_user_id = user.user_id');
					$this->db->where(array('user_id' => $row->FK_rater_user_id));
					$result1 = $this->db->get();
					
					$username_result = $result1->result();
					$rated_by_name = $username_result[0]->user_name;
					
                    $data[$row->rating_id] = array(                        
                        'rating_id' => $row->rating_id,
                        'user_name' => $row->user_name,
                        'rater_user_name' => $rated_by_name,
                        'rater_user_id' => $row->FK_rater_user_id,
                        'rate' => $row->rate,
						'rating_status' => $row->rating_status,
						'date' => $row->date,
						'time' => $row->time,
						'rate_type' => $row->rate_type,
						'last_login' => $row->last_login,
						'last_logout' => $row->last_logout,
					);
                    array_push($arr_value, $data[$row->rating_id]);                    
                }
            } 
			return $arr_value;
        }else{
			return false;
		}*/		
	}
			
	/* ==================================================================== */
	/**
     *  This function is used to get rating, revel request status by user id for Notification  page
     */
	 
	public function updatenote_post($id, $notifications){
        $data = array(
            'notifications' => $notifications,
        );
        $result = $this->db->update('restapi_user', $data, array('user_id' => $id));
        if ($this->db->affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }	
	}
			
	/* ==================================================================== */
	/**
     *  This function is used to update Publicize my testimonials by user id.
     */
	 
	public function updatepmt_post($id, $publicize_my_testimonials){
        $data = array(
            'publicize_my_testimonials' => $publicize_my_testimonials,
        );
        $result = $this->db->update('restapi_user', $data, array('user_id' => $id));
        if ($this->db->affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }	
	}
	/* ==================================================================== */
	/**
     *  This function is used to update Publicize my ratings  by user id.
     */
	 
	public function updatepmr_post($id, $publicize_my_rating){
        $data = array(
            'publicize_my_rating' => $publicize_my_rating,
        );
        $result = $this->db->update('restapi_user', $data, array('user_id' => $id));
        if ($this->db->affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }	
	}
	/* ==================================================================== */
	/**
     *  This function is used to update rate anonymously by user id.
     */
	 
    function updaterateanony_post($id, $rate_anonymously){
        $data = array(
            'rate_anonymously' => $rate_anonymously,
        );
        $result = $this->db->update('restapi_user', $data, array('user_id' => $id));
        if ($this->db->affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }	
	}
	/* ==================================================================== */
	/**
     *  This function is used to update Reveal Requests Remaining by user id.
     */
	 
    function updaterrevelreq_post($id, $reveal_request_remaining){
        $data = array(
            'reveal_request_remaining' => $reveal_request_remaining,
        );
        $result = $this->db->update('restapi_user', $data, array('user_id' => $id));
        if ($this->db->affected_rows()) {
		
			$this->db->select('reveal_request_remaining');
			$this->db->from('user as user');
			$this->db->where(array('user_id' => $id));
			$result1 = $this->db->get();
			
			$username_result = $result1->result();
			$reveal_request_remaining = $username_result[0]->reveal_request_remaining;
			
            return $reveal_request_remaining;
        } else {
            return FALSE;
        }	
	}
	
	/* ==================================================================== */
	/**
     *  This function is used to rate friend.
     */
	 
    function ratetofriend_post($FK_rater_user_id, $FK_rated_user_id, $rate, $rate_type, $rating_status){
		date_default_timezone_set('Asia/Kolkata');
		$data = array(
            'FK_rater_user_id' => $FK_rater_user_id,
            'FK_rated_user_id' => $FK_rated_user_id,
            'rate' => $rate,
            'rating_status' => $rating_status,
            'rate_type' => $rate_type,
            'time' => date('H:m:s'),
            'date' => date('Y-m-d')
        );
		$result = $this->db->insert('restapi_rating', $data);
		
        if ($result) {
            return TRUE;
        } else {
            return FALSE;
        }
	}
	
	/* ==================================================================== */
	/**
     *  This function is used to get user details by user id for rating history page
     */
	 
	public function rating_history_detail_by_user_id($id){
		$this->db->from('restapi_rating as rating');
		$this->db->join('restapi_user as user', 'rating.FK_rater_user_id = user.user_id');
		$this->db->where(array('user.user_id' => $id));
		$result = $this->db->get();
		$arr_value = array();
        $data = array();
		if ($result && $result->num_rows() > 0) {            
            foreach ($result->result() as $row) {
                if (!array_key_exists($row->rating_id, $data)) {
                    $data[$row->rating_id] = array();
                }
                if (array_key_exists($row->rating_id, $data)) {
                    $data[$row->rating_id] = array(                        
                        'rating_id' => $row->rating_id,
                        'rater_user_name' => $row->user_name,
						'user_id' =>  $row->user_id,
						'rate' => $row->rate,
						'date' => $row->date,
						'time' => $row->time,
						'status ' => $row->rating_status,
						'rate_type' => $row->rate_type,
					);
                    array_push($arr_value, $data[$row->rating_id]);                    
                }
            } 
			return $arr_value;
        }else{
			return false;
		}		
	}
		
	/* ==================================================================== */
	/**
     *  This function is used to get user profile status if new then create new 
     */
	 
	public function profile_signup_status($id, $name, $status){
		/*Check whether user_id is already exist or not */
		$db_result = $this->db->get_where('restapi_user', array('user_id' => $id));
		$response_status = array('status' => 200);
		if ($db_result && $db_result->num_rows() > 0) {     
			#user exist, update data
			$data = array(
				'user_id' => $id,
				'user_name' => $name,
				'user_status' => $status,
			);
			$result = $this->db->update('restapi_user', $data, array('user_id' => $id));
			if ($this->db->affected_rows()) {
				return $response_status;
			} else {
				return $response_status;
			}
		}else{
			#new user create account
			$data = array(
				'user_id' => $id,
				'user_name' => $name,
				'user_status' => $status,
			);
			$result = $this->db->insert('restapi_user', $data);
			if ($result) {
				return $response_status;
			} else {
				return $response_status;
			}
		}
	
	}
	
	
	
}
