-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 18, 2015 at 04:13 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mayas`
--

-- --------------------------------------------------------

--
-- Table structure for table `mayas_aboutus`
--

CREATE TABLE IF NOT EXISTS `mayas_aboutus` (
  `aboutus_id` int(10) NOT NULL AUTO_INCREMENT,
  `aboutus1` varchar(5000) NOT NULL,
  `aboutus2` varchar(5000) NOT NULL,
  `aboutus3` varchar(5000) NOT NULL,
  `aboutus4` varchar(5000) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`aboutus_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mayas_aboutus`
--

INSERT INTO `mayas_aboutus` (`aboutus_id`, `aboutus1`, `aboutus2`, `aboutus3`, `aboutus4`, `status`) VALUES
(1, 'Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio.<br />\nLorem ipsum dolor sit amet', 'Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat consectetuer adipiscing elit. Nunc suscipit. Suspendisse enim arcu, convallis non, cursus sed, dignissim et, est. Aenean semper aliquet libero. In ante velit, cursus ut, ultrices vitae, tempor ut, risus. Duis pulvinar. Vestibulum vel pede at sapien sodales mattis. Quisque pretium, lacus nec iaculis vehicula, arcu libero consectetuer massa, auctor aliquet mauris ligula id ipsum. Vestibulum pede. Maecenas sit amet augue. Sed blandit lect', 'jioasdasdsaLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. U<br />\n<br />\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat consectetuer adipiscing elit.<br />\n', 'jiLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. U<br />\n<br />\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna. Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat consectetuer adipiscing elit.<br />\n', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `mayas_birth_stone`
--

CREATE TABLE IF NOT EXISTS `mayas_birth_stone` (
  `birth_stone_id` int(10) NOT NULL AUTO_INCREMENT,
  `birth_stone_name` varchar(100) NOT NULL,
  `birth_stone_navi` varchar(200) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`birth_stone_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `mayas_birth_stone`
--

INSERT INTO `mayas_birth_stone` (`birth_stone_id`, `birth_stone_name`, `birth_stone_navi`, `status`) VALUES
(5, 'done', 'done', 'active'),
(6, 'adsa', 'adasdsa', 'old');

-- --------------------------------------------------------

--
-- Table structure for table `mayas_menu`
--

CREATE TABLE IF NOT EXISTS `mayas_menu` (
  `menu_id` int(10) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(100) NOT NULL,
  `menu_navi` varchar(200) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mayas_menu`
--

INSERT INTO `mayas_menu` (`menu_id`, `menu_name`, `menu_navi`, `status`) VALUES
(1, 'asdfdsfok', 'sfsdfsaok', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `mayas_product`
--

CREATE TABLE IF NOT EXISTS `mayas_product` (
  `product_id` int(10) NOT NULL AUTO_INCREMENT,
  `product_categories` varchar(100) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_description` varchar(200) NOT NULL,
  `product_price_ind` int(10) NOT NULL,
  `product_price_usd` int(10) NOT NULL,
  `product_feature` varchar(100) NOT NULL,
  `product_weight` varchar(100) NOT NULL,
  `product_shape` varchar(100) NOT NULL,
  `product_color` varchar(100) NOT NULL,
  `product_clarity` varchar(100) NOT NULL,
  `product_grade` varchar(100) NOT NULL,
  `product_cut` varchar(100) NOT NULL,
  `product_treatment` varchar(100) NOT NULL,
  `product_origin` varchar(100) NOT NULL,
  `product_other_info` varchar(100) NOT NULL,
  `product_other_info2` varchar(100) NOT NULL,
  `product_other_info3` varchar(100) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  `product_image_list` varchar(1000) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `mayas_product`
--

INSERT INTO `mayas_product` (`product_id`, `product_categories`, `product_name`, `product_description`, `product_price_ind`, `product_price_usd`, `product_feature`, `product_weight`, `product_shape`, `product_color`, `product_clarity`, `product_grade`, `product_cut`, `product_treatment`, `product_origin`, `product_other_info`, `product_other_info2`, `product_other_info3`, `status`, `product_image_list`) VALUES
(1, '1', 'hghfgfgggggggggggg', 'ghfgfffffffgggggggggggg', 454545444, 2147483647, 'fgdfg', '3534', 'fgdf', 'fdgdf', 'fgd', 'dfgdf', 'dfgd', 'fgdf', 'dfg', 'fdg', 'dfg', 'dfg', 'active', 'product_55a8d14da5ade.jpg,product_55aa038b8e640.jpg,product_55aa0394cacd6.jpg,product_55aa039e32d9e.jpg,product_55aa03cf2004a.jpg,product_55aa03d5cc298.jpg,product_55aa03df30cdd.jpg,product_55aa03e76a352.jpg,'),
(2, '1', 'SAsaaaaaaaaaaaa', 'ASaaaaaaaa', 2147483647, 2147483647, 'fsdf', 'fsdf', 'df', 'df', 'df', 'df', 'df', 'df', 'df', 'df', 'df', 'df', 'active', 'product_55a8d1544600d.jpg,'),
(3, '2', 'fgdfgxcx', 'fgdfg', 545, 545, 'dfs', 'dfsd', 'dfs', 'sdfs', 'df', 'df', 'sdfxc', 'f', 'df', 'df', 'f', 'df', 'active', 'product_55a4f46976f4c.jpg,'),
(4, '1', '11', '22', 333, 4444, '5555', '6555', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', 'active', 'product_55a5104e1aad1.jpg,'),
(5, '1', '1', '2', 3, 4, '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', 'active', 'product_55a8d15b83966.jpg,'),
(6, '1', '1', '2', 3, 4, '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', 'active', 'product_55a8d1614703a.jpg,'),
(7, '1', '1', '2', 3, 4, '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', 'active', 'product_55a8d165d6810.jpg,'),
(8, '1', '1', '2', 3, 4, '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', 'active', 'product_55a8d16b67ed6.jpg,'),
(9, '1', '1', '2', 3, 4, '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', 'active', 'product_55a8d17138fb1.jpg,'),
(10, '1', '1', '2', 3, 4, '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', 'active', 'product_55a8d1761f8f7.jpg,'),
(11, '1', '1', '2', 3, 4, '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', 'active', 'product_55a8d17b36f22.jpg,'),
(12, '1', '1', '2', 3, 4, '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', 'active', 'product_55a8d1a264564.jpg,'),
(13, '1', 'jlkjhkj', 'j', 78, 68768, '798', '', '', '', '', '', '', '', '', '', '', '', 'active', 'product_55a90114ecd5e.jpg,');

-- --------------------------------------------------------

--
-- Table structure for table `mayas_services`
--

CREATE TABLE IF NOT EXISTS `mayas_services` (
  `service_id` int(10) NOT NULL AUTO_INCREMENT,
  `services_name` varchar(200) NOT NULL,
  `services_type` enum('main','other') NOT NULL,
  `services_main_description` varchar(1000) NOT NULL,
  `services_description` varchar(5000) NOT NULL,
  `services_image` varchar(100) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `mayas_services`
--

INSERT INTO `mayas_services` (`service_id`, `services_name`, `services_type`, `services_main_description`, `services_description`, `services_image`, `status`) VALUES
(1, 'jhkjh', 'other', 'jhkjh', 'hjh', 'service_559e569c3ce09.jpg', 'active'),
(2, 'gjhgjg', 'other', 'hjgh', 'gjh\n\nhghjg', 'service_559e097545d4d.jpg', 'active'),
(3, 'adsasd', 'main', 'adsa', 'adsasd<br />\ns<br />\ndas<br />\nd<br />\nsad<br />\nasd<br />\nas<br />\nads<br />\ndsa<br />\n', 'service_559e44d07d093.jpg', 'active'),
(4, 'dfsd', 'main', 'kjfdjf', 'jkjgdfg fgjkfg ', 'service_55a3730059334.jpg', 'active'),
(5, 'fhfhttt', 'main', 'kfgjgfgjkf', 'ortoomoorto', 'service_55a3732ae32ad.jpg', 'active'),
(6, 'oooooooo', 'main', 'cncmxncmnxm', 'xznzxmc', 'service_55a3734a9ba9a.png', 'active'),
(7, 'qqqqqqqqqq', 'other', 'qqqqqqqqqqq', 'qqqqqqqqqqqqqq', 'service_55a37365e3d7f.jpg', 'active'),
(8, 'wwwwwwww', 'other', 'wwwwwwwwwwwww', 'wwwwwwwwwwwwwwwww', 'service_55a3737ad4590.jpg', 'active'),
(9, 'eeeeeeeeee', 'other', 'eeeeeeeeeeeee', 'eeeeeeeeeeeeeeeee', 'service_55a373952d74a.jpg', 'active'),
(10, 'rrrrrrrrrr', 'other', 'rrrrrrrrrrrrr', 'rrrrrrrrrrrrrrr', 'service_55a373a65816b.jpg', 'active'),
(11, 'yyyyyyyyyyy', 'other', 'yyyyyyyyyyyyyyy', 'yyyyyyyyyyyyy', 'service_55a373ba6a8c8.jpg', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `mayas_slider`
--

CREATE TABLE IF NOT EXISTS `mayas_slider` (
  `slider_id` int(10) NOT NULL AUTO_INCREMENT,
  `slider_info` varchar(200) NOT NULL,
  `slider_navi` varchar(200) NOT NULL,
  `slider_image` varchar(200) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`slider_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mayas_slider`
--

INSERT INTO `mayas_slider` (`slider_id`, `slider_info`, `slider_navi`, `slider_image`, `status`) VALUES
(1, 'dsadas', 'http://www.sds.sdok', 'slider_559031968e022.png', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `mayas_special_feature`
--

CREATE TABLE IF NOT EXISTS `mayas_special_feature` (
  `special_feature_id` int(10) NOT NULL AUTO_INCREMENT,
  `special_feature_heading` varchar(100) NOT NULL,
  `sub_heading` varchar(100) NOT NULL,
  `small_sub_heading_message` varchar(100) NOT NULL,
  `point1` varchar(100) NOT NULL,
  `point2` varchar(100) NOT NULL,
  `point3` varchar(100) NOT NULL,
  `point4` varchar(100) NOT NULL,
  `point5` varchar(100) NOT NULL,
  `point6` varchar(100) NOT NULL,
  `point7` varchar(100) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`special_feature_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mayas_special_feature`
--

INSERT INTO `mayas_special_feature` (`special_feature_id`, `special_feature_heading`, `sub_heading`, `small_sub_heading_message`, `point1`, `point2`, `point3`, `point4`, `point5`, `point6`, `point7`, `status`) VALUES
(1, 'done', 'jklj', 'hj', 'hkj', 'hk', 'jh', 'kjh', 'kj', 'hkj', 'hkj', 'active'),
(2, 'djfksdj', 'jkfk', 'jkrewk', 'dfsdf', 'djfkj', 'jkdfji', 'fsdkfj', 'jkdfi', 'jkfdji', 'jkjf', 'active'),
(3, 'iioos', 'kdfjs', 'kdfi', 'kii', 'kkjj', 'jjfuu', 'kkk', 'kklao', 'jklju', 'kljlj', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `mayas_sub_menu_products`
--

CREATE TABLE IF NOT EXISTS `mayas_sub_menu_products` (
  `sub_menu_products_id` int(10) NOT NULL AUTO_INCREMENT,
  `sub_menu_products_name` varchar(100) NOT NULL,
  `sub_menu_products_navi` varchar(200) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  `sub_menu_products_image` varchar(200) NOT NULL,
  PRIMARY KEY (`sub_menu_products_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `mayas_sub_menu_products`
--

INSERT INTO `mayas_sub_menu_products` (`sub_menu_products_id`, `sub_menu_products_name`, `sub_menu_products_navi`, `status`, `sub_menu_products_image`) VALUES
(1, 'Ring', 'Ring', 'active', 'sub_menu_product_55a7922a1add1.jpg'),
(2, 'Neckless', 'Neckless', 'active', 'sub_menu_product_55a783b359fb5.jpg'),
(3, 'Earings', 'Earings', 'active', 'sub_menu_product_55a792437b24c.jpg'),
(4, 'Braceltes', 'Braceltes', 'active', 'sub_menu_product_55a79257b04bb.jpg'),
(5, 'aaa', 'aaa', 'old', ''),
(6, 'abbbb', 'bbbb', 'old', ''),
(7, 'qqqq', 'qqqq', 'old', 'product_55a668a84bca6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mayas_sub_menu_services`
--

CREATE TABLE IF NOT EXISTS `mayas_sub_menu_services` (
  `sub_menu_services_id` int(10) NOT NULL AUTO_INCREMENT,
  `sub_menu_services_name` varchar(100) NOT NULL,
  `sub_menu_services_navi` varchar(200) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`sub_menu_services_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mayas_sub_menu_services`
--

INSERT INTO `mayas_sub_menu_services` (`sub_menu_services_id`, `sub_menu_services_name`, `sub_menu_services_navi`, `status`) VALUES
(1, 'done', 'done', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `mayas_users`
--

CREATE TABLE IF NOT EXISTS `mayas_users` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `userrole` varchar(100) NOT NULL,
  `password_hash` varchar(100) NOT NULL,
  `verify_code` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `created_time` varchar(100) NOT NULL,
  `status` enum('active','old') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mayas_users`
--

INSERT INTO `mayas_users` (`user_id`, `username`, `email`, `userrole`, `password_hash`, `verify_code`, `created_date`, `created_time`, `status`) VALUES
(1, 'asdsad', 'asdsad@adasd.asd', 'done', 'c768776522ebeeebe926d624cea2715ab804909f', 'lorwKg4dgTNepSa7', '2015-06-28', '22:06:47', 'active'),
(3, 'admin', 'admin@mayas.com', 'admin', '9a4c36600c5c178e1fe43297535cd91e2f655ef8', 'bZbw722iNhGKoQMv', '2015-06-28', '22:06:31', 'active');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
